package com.example.loginactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.List;

public class homepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        ParseQuery<ParseObject> query = ParseQuery.getQuery("Person");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                if (e == null) {
                    // Query successful, objects contains the retrieved data
                    for (ParseObject object : objects) {
                        String name = object.getString("name");
                        String Fname = object.getString("Family Name");
                        String email = object.getString("email");
                        String password = object.getString("password");


                        // Do something with the data
                        Log.d("Parse", "Name: " + name + ", Family Name: " + Fname +",email "+email+", password"+password);
                    }
                } else {
                    // Something went wrong with the query
                    Log.e("Parse", "Error querying data: " + e.getMessage());
                }
            }
        });
    }
    }
