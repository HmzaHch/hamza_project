import android.app.Application;
import com.parse.Parse;

public class MyApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        // Initialize Parse with your application ID and server URL
        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("BxH3jlgTWb1x3lEHsW72ttl5OgOWdkksMO9floPx")
                .clientKey("zKYohp22oQpoMpjR9JnUbL8lmxDVqNRmuqRY7uko")
                .server("https://parseapi.back4app.com")
                .build()
        );
    }
}

